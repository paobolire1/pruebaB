var createScene = function() {
    
    var scene = new BABYLON.Scene(engine);
    // Add a camera to the scene and attach it to the canvas
    // Add a lights to the scene
    //Your Code
  return scene;
};